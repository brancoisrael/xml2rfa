using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Text;
using System.Windows.Forms;


namespace C_SHARP_TUTORIAL
{
    public partial class Form1 : Form
    {

        RFCOMAPILib.User selectedUser;
        RFCOMAPILib.FaxServer fxServer;
        int faxHandle;
        String faxUniqueID;

        public Form1()
        {
            InitializeComponent();


            fxServer = new RFCOMAPILib.FaxServer();
            fxServer.ServerName = "JR2003";
            fxServer.Protocol = RFCOMAPILib.CommunicationProtocolType.cpNamedPipes;
            fxServer.AuthorizationUserID = "Administrator";
            fxServer.AuthorizationUserPassword = "";
            fxServer.UseNTAuthentication = RFCOMAPILib.BoolType.False;

            foreach (RFCOMAPILib.User user in fxServer.Users)
            {
                listBox1.Items.Add(user.ID);
            }
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            selectedUser = fxServer.Users[this.listBox1.SelectedIndex + 1];
        }

        private void button1_Click(object sender, EventArgs e)
        {
            
            //string str_FaxFileName;
            //string str_FromName;
            string str_handle;
            string str_uniquename;
           
            RFCOMAPILib.Faxes colFaxes;
       
            listBox2.Items.Clear();
            colFaxes = fxServer.get_Faxes(selectedUser.ID);
            foreach (RFCOMAPILib.Fax obj_Fax in colFaxes)
            {
                //str_FaxFileName = obj_Fax.FaxFilename;
                //str_FromName = obj_Fax.FromName;
                str_handle = (obj_Fax.Handle).ToString();
                str_uniquename = obj_Fax.UniqueID;

                listBox2.Items.Add(str_handle + " " + str_uniquename);
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try{
                RFCOMAPILib.Fax obj_Fax;
            
                //create the fax object
                obj_Fax = (RFCOMAPILib.Fax)fxServer.get_CreateObject(RFCOMAPILib.CreateObjectType.coFax);

                //now set the sender
                obj_Fax.FromName = "RF COMAPI Tutorial";
                //obj_Fax.EmailSubject = "Please reply to email@domain.com";
                //obj_Fax.ToEmailAddress = "erinstone@captaris.com";
                obj_Fax.ToFaxNumber = "2247";
                obj_Fax.ToName = "Bill &amp; Ted";
                obj_Fax.Owner = selectedUser;
                obj_Fax.IsINLJob = RFCOMAPILib.BoolType.False;
                obj_Fax.FCSFilename = fxServer.CoverSheets[1].LongFileName;
                obj_Fax.HasCoversheet = RFCOMAPILib.BoolType.True;
                obj_Fax.set_CoverSheetNotes(1, "This is the coversheet note uniqueid is DLRTEST001");
                //obj_Fax.EnableSendViaSecureDocs(RFCOMAPILib.BoolType.False, RFCOMAPILib.BoolType.False, "");
                //obj_Fax.DelayFaxSendDateTime = new DateTime(2008, 10, 13, 14, 55, 0);
                //obj_Fax.UniqueID = "DLRTEST001";
                obj_Fax.Send();
                this.faxHandle = obj_Fax.Handle;
                this.faxUniqueID = obj_Fax.UniqueID;
            }catch (System.Exception ex){
                MessageBox.Show("error in sending: " + ex.ToString());
            }finally{
                MessageBox.Show("end of the sending method");
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                RFCOMAPILib.Fax obj_Fax;
              
               
             
                //create the fax object
                obj_Fax = (RFCOMAPILib.Fax)fxServer.get_CreateObject(RFCOMAPILib.CreateObjectType.coFax);
                //obj_Attachment = (RFCOMAPILib.Attachment)fxServer.get_CreateObject(RFCOMAPILib.CreateObjectType.coAttachment);
               
                //now set the sender
                obj_Fax.FromName = "RF TestUser";
                obj_Fax.EmailSubject = "Please reply to email@domain.com";
                obj_Fax.ToEmailAddress = "erinstone@captaris.com";
                obj_Fax.Owner = selectedUser;
                //obj_Fax.FCSFilename = fxServer.CoverSheets[1].LongFileName;
                obj_Fax.HasCoversheet = RFCOMAPILib.BoolType.True;
                obj_Fax.set_CoverSheetNotes(1, "Please reply to name@domain.com");
                obj_Fax.EnableSendViaSecureDocs(RFCOMAPILib.BoolType.False, RFCOMAPILib.BoolType.False, "");
                obj_Fax.Attachments.Add("C:\\temp\\Sample_Tif_Image.TIF", RFCOMAPILib.BoolType.False);
                obj_Fax.Attachments.Add("C:\\temp\\Sample Tif Image2.TIF", RFCOMAPILib.BoolType.False);
                obj_Fax.Attachments.Add(@"C:\\temp\\test.pdf", RFCOMAPILib.BoolType.False);
                
               
     
                
                obj_Fax.Send();
            }
            catch (System.Exception ex)
            {
                MessageBox.Show("error in sending: " + ex.ToString());
            }
            finally
            {
                MessageBox.Show("end of the sending method");
            }
        }

        private void button4_Click(object sender, EventArgs e)
        {
            RFCOMAPILib.Fax obj_Fax;
            string[] faxInfo = new string[2];
            faxInfo = ((string)this.listBox2.SelectedItem).Split(' ');
            obj_Fax = this.fxServer.get_Fax(faxInfo[0]);
            MessageBox.Show("Fax status is: " + obj_Fax.FaxStatus);
            MessageBox.Show("Fax isReceived: " + obj_Fax.IsReceived);
            MessageBox.Show("Fax isApproved: " + obj_Fax.IsApproved);
            if (obj_Fax.Folder.ID != "Backup")
            {
                MessageBox.Show("Folder: " + obj_Fax.Folder.ID);
            }
            else
            {
                MessageBox.Show("backup");
            }
        }

        private void listBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            txtFAxID.Text = (string)this.listBox2.SelectedItem;
        }

        private void button5_Click(object sender, EventArgs e)
        {
            RFCOMAPILib.Fax obj_Fax;
            string[] faxInfo = new string[2];
            faxInfo = ((string)this.txtFAxID.Text).Split(' ');
            obj_Fax = this.fxServer.get_Fax(faxInfo[0]);
            if (obj_Fax.IsDeleted == RFCOMAPILib.BoolType.True)
            {
                MessageBox.Show("Fax has been deleted");
                
            }
            else
            {
                MessageBox.Show("Fax status is: " + obj_Fax.FaxStatus.ToString());
                MessageBox.Show("Fax isReceived: " + obj_Fax.IsReceived);
                MessageBox.Show("Fax isApproved: " + obj_Fax.IsApproved);
                MessageBox.Show("fax billing info: " + obj_Fax.BillingCode.BillInfo1 + " " + obj_Fax.BillingCode.BillInfo2);
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            RFCOMAPILib.Fax obj_Fax;
            RFCOMAPILib.Attachment obj_Attachment;
           
            string[] faxInfo = new string[2]; //this has two elements, first is the handle, second is the unique id
            int numPages = 0;
            faxInfo = ((string)this.txtFAxID.Text).Split(' ');
            obj_Fax = this.fxServer.get_Fax(faxInfo[1]);
            if (faxInfo[1].Equals(obj_Fax.UniqueID)){
                MessageBox.Show ("unique IDs are equals");
            }
            
            numPages = obj_Fax.Attachments.Count;
            MessageBox.Show("num Pages is: " + numPages.ToString());
            
            obj_Attachment = obj_Fax.Attachments[1];
            string filename = obj_Attachment.FileName;            
            MessageBox.Show("description is:  " +filename);

        }

        private void button7_Click(object sender, EventArgs e)
        {
            RFCOMAPILib.Fax obj_Fax;
            RFCOMAPILib.User obj_User;
            obj_User = (RFCOMAPILib.User)fxServer.get_CreateObject(RFCOMAPILib.CreateObjectType.coUser);
            obj_User = fxServer.get_User("ARCHIVEUSER");

            string[] faxInfo = new string[2]; //this has two elements, first is the handle, second is the unique id
            
            faxInfo = ((string)this.txtFAxID.Text).Split(' ');
            obj_Fax = this.fxServer.get_Fax(faxInfo[0]);
            if (obj_Fax.FaxStatus.Equals(RFCOMAPILib.FaxStatusType.fsDoneOK))
            {
                try
                {
                    //then route to archive user
                    RFCOMAPILib.Users col_Users;
                    col_Users = fxServer.Users;
                    col_Users.RemoveAll();
                    col_Users.Add(obj_User);
                    obj_Fax.ForwardToUsers(col_Users, "check out this fax");


                    //obj_Fax.RouteToUser(obj_User, "Please Archive");
                }
                catch (Exception ex)
                {
                    MessageBox.Show("error message: " + ex.Message.ToString());
                }
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
             try
            {
                RFCOMAPILib.Fax obj_Fax;
             
                //create the fax object
                obj_Fax = (RFCOMAPILib.Fax)fxServer.get_CreateObject(RFCOMAPILib.CreateObjectType.coFax);
            
                //now set the sender
                obj_Fax.FromName = "RF TestUser";
                obj_Fax.EmailSubject = "Please reply to email@domain.com";
                obj_Fax.ToEmailAddress = "erinstone@captaris.com";
                obj_Fax.Owner = selectedUser;
                obj_Fax.FCSFilename = fxServer.CoverSheets[1].LongFileName;
                obj_Fax.HasCoversheet = RFCOMAPILib.BoolType.True;
                obj_Fax.set_CoverSheetNotes(1, "Please reply to name@domain.com");
                //obj_Fax.EnableSendViaSecureDocs(RFCOMAPILib.BoolType.False, RFCOMAPILib.BoolType.False, "");
                obj_Fax.UniqueID = "EZF_NATIVE_TEST";
                //this use of AddNativeDocument will put in a random name for the file
                obj_Fax.Attachments.AddNativeDocument("C:\\temp\\Sample_Tif_Image.TIF", "", RFCOMAPILib.BoolType.False);
                //this use of AddNativeDocument will correctly identify the document by name/type
                obj_Fax.Attachments.AddNativeDocument("C:\\temp\\Sample Tif Image2.TIF", "Sample Tif Image2.TIF", RFCOMAPILib.BoolType.False);
                obj_Fax.Attachments.AddNativeDocument("C:\\temp\\test.pdf", "test.pdf", RFCOMAPILib.BoolType.False);
            
                obj_Fax.Send();
            }
            catch (System.Exception ex)
            {
                System.Diagnostics.Debug.WriteLine("error in sending: " + ex.ToString());
            }
            finally
            {
                System.Diagnostics.Debug.WriteLine("end of the sending method");
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            selectedUser.ChangePassword("12345");
            MessageBox.Show("Password has been changed");
        }

     

        private void btnSaveToXML_Click(object sender, EventArgs e)
        {
            RFCOMAPILib.Fax obj_Fax;
            string[] faxInfo = new string[2];
            faxInfo = ((string)this.listBox2.SelectedItem).Split(' ');
            obj_Fax = this.fxServer.get_Fax(faxInfo[0]);
            string xmlString = null;
            xmlString = obj_Fax.get_XMLEx(RFCOMAPILib.BoolType.True, RFCOMAPILib.BoolType.True, RFCOMAPILib.BoolType.True, 1);
            System.Diagnostics.Debug.WriteLine(xmlString);
            obj_Fax.SaveToXML(@"C:\temp\fax_to_xml.xml", RFCOMAPILib.BoolType.True, RFCOMAPILib.BoolType.True, RFCOMAPILib.BoolType.True, 1, RFCOMAPILib.BoolType.False);
        }

        private void btnSendRetries_Click(object sender, EventArgs e)
        {
            try
            {
                RFCOMAPILib.Fax obj_Fax;

                //create the fax object
                obj_Fax = (RFCOMAPILib.Fax)fxServer.get_CreateObject(RFCOMAPILib.CreateObjectType.coFax);

                //now set the sender
                obj_Fax.FromName = "RF COMAPI Tutorial";
               
                //set the fax number to send to and the name of the person to send to
                obj_Fax.ToFaxNumber = "2247";
                obj_Fax.ToName = "Bill Williamson";
               
                //set coversheet information
                obj_Fax.FCSFilename = fxServer.CoverSheets[1].LongFileName;
                obj_Fax.HasCoversheet = RFCOMAPILib.BoolType.True;
                obj_Fax.set_CoverSheetNotes(1, "This is the coversheet note uniqueid is DLRTEST001");
                
                //set max number of retries and time between tries
                obj_Fax.MaximumRetries = 5;
                obj_Fax.TryInterval = 2;

                //send the fax
                obj_Fax.Send();
               
            }
            catch (System.Exception ex)
            {
                MessageBox.Show("error in sending: " + ex.ToString());
            }
            finally
            {
                MessageBox.Show("end of the sending method");
            }

        }

        private void btnForwardToUsers_Click(object sender, EventArgs e)
        {
            try
            {
                RFCOMAPILib.Fax obj_Fax;
                RFCOMAPILib.Users obj_Users;

                string[] faxInfo = new string[2];
                faxInfo = ((string)this.listBox2.SelectedItem).Split(' ');
                obj_Fax = this.fxServer.get_Fax(faxInfo[0]);
                
                //create the users collection
                obj_Users = (RFCOMAPILib.Users)fxServer.get_CreateObject(RFCOMAPILib.CreateObjectType.coUsers);

                obj_Users.RemoveAll();
                RFCOMAPILib.User objUser = fxServer.get_User("ERINSTONE");
                obj_Users.Add(objUser);
                obj_Fax.ForwardToUsers(obj_Users, "Here is the notes");
                

               
            }
            catch (System.Exception ex)
            {
                MessageBox.Show("error in sending: " + ex.ToString());
            }
            finally
            {
                MessageBox.Show("end of the sending method");
            }
        }

        private void btnFwdNewNum_Click(object sender, EventArgs e)
        {
            RFCOMAPILib.Fax obj_Fax;
            RFCOMAPILib.Fax fwd_Fax;
            string[] faxInfo = new string[2];
            faxInfo = ((string)this.listBox2.SelectedItem).Split(' ');
            obj_Fax = this.fxServer.get_Fax(faxInfo[0]);
            obj_Fax.ForwardToNewFaxNumber();
            fwd_Fax.E
        }

        

        
    }
}